#include <ItemComponent.h>
#include <CollisionComponent.h>
#include <iostream>

bool itemCatch(){
}

bool itemDrop(){
}






