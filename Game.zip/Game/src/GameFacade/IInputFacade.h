#pragma once

class IInputFacade{

public:

    //Constructor
    IInputFacade(){}

    //Destructor
    virtual ~IInputFacade(){}

};